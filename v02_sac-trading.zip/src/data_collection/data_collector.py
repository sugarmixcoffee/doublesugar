"""
Alpha Vantage API를 사용하여 주식 데이터를 수집하는 모듈
"""
import os
import time
import pandas as pd
import numpy as np
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Union, Any
from alpha_vantage.timeseries import TimeSeries

from src.config.config import (
    ALPHA_VANTAGE_API_KEY,
    API_CALL_DELAY,
    DATA_DIR,
    TARGET_SYMBOLS,
    DATA_START_DATE,
    DATA_FREQUENCY,
    LOGGER
)
from src.utils.utils import create_directory, save_to_csv, load_from_csv

class DataCollector:
    """
    Alpha Vantage API를 사용하여 주식 데이터를 수집하는 클래스
    """
    
    def __init__(self, api_key: str = ALPHA_VANTAGE_API_KEY, symbols: List[str] = None):
        """
        DataCollector 클래스 초기화
        
        Args:
            api_key: Alpha Vantage API 키
            symbols: 수집할 주식 심볼 리스트 (None인 경우 설정 파일의 기본값 사용)
        """
        self.api_key = api_key
        self.symbols = symbols if symbols is not None else TARGET_SYMBOLS
        self.time_series = TimeSeries(key=self.api_key, output_format='pandas')
        self.data_dir = DATA_DIR
        create_directory(self.data_dir)
        LOGGER.info(f"DataCollector 초기화 완료: {len(self.symbols)}개 종목 대상")
    
    def collect_daily_data(self, symbol: str, output_size: str = 'full') -> pd.DataFrame:
        """
        일별 주식 데이터 수집
        
        Args:
            symbol: 주식 심볼
            output_size: 'compact' (최근 100일) 또는 'full' (최대 20년)
            
        Returns:
            수집된 일별 주식 데이터 데이터프레임
        """
        try:
            LOGGER.info(f"{symbol} 일별 데이터 수집 시작...")
            data, meta_data = self.time_series.get_daily(symbol=symbol, outputsize=output_size)
            
            # 데이터 전처리
            data = data.sort_index()  # 날짜 오름차순 정렬
            data.index.name = 'date'
            data.columns = ['open', 'high', 'low', 'close', 'volume']  # 컬럼명 소문자로 변경
            
            # 시작 날짜 이후 데이터만 필터링
            if DATA_START_DATE:
                data = data[data.index >= DATA_START_DATE]
            
            LOGGER.info(f"{symbol} 데이터 수집 완료: {len(data)} 행")
            return data
            
        except Exception as e:
            LOGGER.error(f"{symbol} 데이터 수집 실패: {str(e)}")
            return pd.DataFrame()
    
    def collect_all_symbols(self) -> Dict[str, pd.DataFrame]:
        """
        모든 심볼에 대한 데이터 수집
        
        Returns:
            심볼을 키로 하고 데이터프레임을 값으로 하는 딕셔너리
        """
        all_data = {}
        
        for symbol in self.symbols:
            try:
                data = self.collect_daily_data(symbol)
                if not data.empty:
                    all_data[symbol] = data
                
                # API 호출 제한 방지를 위한 지연
                time.sleep(API_CALL_DELAY)
                
            except Exception as e:
                LOGGER.error(f"{symbol} 처리 중 오류 발생: {str(e)}")
        
        LOGGER.info(f"총 {len(all_data)}/{len(self.symbols)} 종목 데이터 수집 완료")
        return all_data
    
    def save_data(self, data: Dict[str, pd.DataFrame], subdir: str = None) -> None:
        """
        수집된 데이터를 CSV 파일로 저장
        
        Args:
            data: 심볼을 키로 하고 데이터프레임을 값으로 하는 딕셔너리
            subdir: 저장할 하위 디렉토리 (None인 경우 날짜 기반으로 생성)
        """
        if subdir is None:
            subdir = datetime.now().strftime("%Y%m%d")
        
        save_dir = self.data_dir / subdir
        create_directory(save_dir)
        
        for symbol, df in data.items():
            file_path = save_dir / f"{symbol}.csv"
            save_to_csv(df, file_path)
        
        LOGGER.info(f"모든 데이터 저장 완료: {save_dir}")
    
    def load_data(self, symbol: str, subdir: str = None) -> pd.DataFrame:
        """
        저장된 데이터 파일에서 데이터 로드
        
        Args:
            symbol: 주식 심볼
            subdir: 로드할 하위 디렉토리 (None인 경우 가장 최근 디렉토리 사용)
            
        Returns:
            로드된 주식 데이터 데이터프레임
        """
        if subdir is None:
            # 가장 최근 디렉토리 찾기
            subdirs = [d for d in os.listdir(self.data_dir) if os.path.isdir(self.data_dir / d)]
            if not subdirs:
                LOGGER.error("저장된 데이터 디렉토리가 없습니다.")
                return pd.DataFrame()
            
            subdirs.sort(reverse=True)  # 최신 날짜가 앞에 오도록 정렬
            subdir = subdirs[0]
        
        file_path = self.data_dir / subdir / f"{symbol}.csv"
        
        try:
            df = load_from_csv(file_path)
            # 날짜 인덱스로 변환
            if 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date'])
                df.set_index('date', inplace=True)
            
            LOGGER.info(f"{symbol} 데이터 로드 완료: {len(df)} 행")
            return df
            
        except Exception as e:
            LOGGER.error(f"{symbol} 데이터 로드 실패: {str(e)}")
            return pd.DataFrame()
    
    def load_all_data(self, subdir: str = None) -> Dict[str, pd.DataFrame]:
        """
        모든 심볼에 대한 저장된 데이터 로드
        
        Args:
            subdir: 로드할 하위 디렉토리 (None인 경우 가장 최근 디렉토리 사용)
            
        Returns:
            심볼을 키로 하고 데이터프레임을 값으로 하는 딕셔너리
        """
        all_data = {}
        
        for symbol in self.symbols:
            data = self.load_data(symbol, subdir)
            if not data.empty:
                all_data[symbol] = data
        
        LOGGER.info(f"총 {len(all_data)}/{len(self.symbols)} 종목 데이터 로드 완료")
        return all_data
    
    def collect_and_save(self) -> Dict[str, pd.DataFrame]:
        """
        데이터 수집 및 저장을 한 번에 수행
        
        Returns:
            수집된 데이터 딕셔너리
        """
        data = self.collect_all_symbols()
        if data:
            self.save_data(data)
        return data


if __name__ == "__main__":
    # 모듈 테스트 코드
    collector = DataCollector()
    data = collector.collect_and_save()
    print(f"수집된 데이터 종목: {list(data.keys())}")
    
    # 첫 번째 종목의 데이터 샘플 출력
    if data:
        symbol = list(data.keys())[0]
        print(f"\n{symbol} 데이터 샘플:")
        print(data[symbol].head()) 
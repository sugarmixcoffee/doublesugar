"""
SAC 모델 평가 실행 스크립트
"""
import os
import argparse
import torch
import numpy as np
from pathlib import Path

from src.config.config import (
    DEVICE,
    TARGET_SYMBOLS,
    LOGGER
)
from src.data_collection.data_collector import DataCollector
from src.preprocessing.data_processor import DataProcessor
from src.environment.trading_env import TradingEnvironment, MultiAssetTradingEnvironment
from src.models.sac_agent import SACAgent
from src.evaluation.evaluator import Evaluator
from src.utils.utils import create_directory, get_timestamp

def parse_args():
    """
    명령줄 인자 파싱
    
    Returns:
        파싱된 인자
    """
    parser = argparse.ArgumentParser(description='SAC 모델 평가 스크립트')
    
    # 데이터 관련 인자
    parser.add_argument('--symbols', nargs='+', default=None, help='평가에 사용할 주식 심볼 목록')
    parser.add_argument('--collect_data', action='store_true', help='데이터 수집 여부')
    
    # 환경 관련 인자
    parser.add_argument('--window_size', type=int, default=30, help='관측 윈도우 크기')
    parser.add_argument('--initial_balance', type=float, default=10000.0, help='초기 자본금')
    parser.add_argument('--multi_asset', action='store_true', help='다중 자산 환경 사용 여부')
    
    # 모델 관련 인자
    parser.add_argument('--model_path', type=str, required=True, help='로드할 모델 경로')
    parser.add_argument('--use_cnn', action='store_true', help='CNN 모델 사용 여부')
    
    # 평가 관련 인자
    parser.add_argument('--num_episodes', type=int, default=1, help='평가할 에피소드 수')
    parser.add_argument('--render', action='store_true', help='환경 렌더링 여부')
    parser.add_argument('--result_prefix', type=str, default='', help='결과 파일 접두사')
    
    return parser.parse_args()

def main():
    """
    메인 함수
    """
    # 인자 파싱
    args = parse_args()
    
    # 심볼 목록 설정
    symbols = args.symbols if args.symbols else TARGET_SYMBOLS
    
    LOGGER.info(f"평가 시작: 대상 심볼 {symbols}")
    
    # 데이터 수집
    collector = DataCollector(symbols=symbols)
    
    if args.collect_data:
        LOGGER.info("데이터 수집 중...")
        data = collector.collect_and_save()
    else:
        LOGGER.info("저장된 데이터 로드 중...")
        data = collector.load_all_data()
        
        if not data:
            LOGGER.warning("저장된 데이터가 없어 데이터를 수집합니다.")
            data = collector.collect_and_save()
    
    if not data:
        LOGGER.error("데이터 수집 실패")
        return
    
    # 데이터 전처리
    LOGGER.info("데이터 전처리 중...")
    processor = DataProcessor(window_size=args.window_size)
    results = processor.process_all_symbols(data)
    
    if not results:
        LOGGER.error("데이터 전처리 실패")
        return
    
    # 환경 생성
    if args.multi_asset:
        # 다중 자산 환경 생성
        LOGGER.info("다중 자산 트레이딩 환경 생성 중...")
        normalized_data_dict = {symbol: result['normalized_data'] for symbol, result in results.items()}
        env = MultiAssetTradingEnvironment(
            data_dict=normalized_data_dict,
            window_size=args.window_size,
            initial_balance=args.initial_balance
        )
        action_dim = len(symbols)
    else:
        # 단일 자산 환경 생성 (첫 번째 심볼 사용)
        symbol = symbols[0]
        LOGGER.info(f"단일 자산 트레이딩 환경 생성 중: {symbol}")
        
        if symbol not in results:
            LOGGER.error(f"{symbol} 데이터 처리 결과가 없습니다.")
            return
        
        normalized_data = results[symbol]['normalized_data']
        env = TradingEnvironment(
            data=normalized_data,
            window_size=args.window_size,
            initial_balance=args.initial_balance,
            symbol=symbol
        )
        action_dim = 1
    
    # 에이전트 생성
    LOGGER.info("SAC 에이전트 생성 중...")
    if args.use_cnn:
        # CNN 모델 사용
        input_shape = (args.window_size, env.feature_dim)
        agent = SACAgent(
            action_dim=action_dim,
            input_shape=input_shape,
            use_cnn=True
        )
    else:
        # 일반 모델 사용
        if isinstance(env, TradingEnvironment):
            state_dim = env.observation_space['market_data'].shape[0] * env.observation_space['market_data'].shape[1] + env.observation_space['portfolio_state'].shape[0]
        else:
            # 다중 자산 환경의 경우 첫 번째 환경의 상태 차원 사용
            first_env = list(env.envs.values())[0]
            state_dim = first_env.observation_space['market_data'].shape[0] * first_env.observation_space['market_data'].shape[1] + first_env.observation_space['portfolio_state'].shape[0]
        
        agent = SACAgent(
            state_dim=state_dim,
            action_dim=action_dim
        )
    
    # 모델 로드
    LOGGER.info(f"모델 로드 중: {args.model_path}")
    agent.load_model(args.model_path)
    
    # 평가기 생성
    LOGGER.info("평가기 생성 중...")
    evaluator = Evaluator(agent=agent, env=env)
    
    # 평가 실행
    LOGGER.info(f"평가 시작: {args.num_episodes}개 에피소드")
    results = evaluator.evaluate(num_episodes=args.num_episodes, render=args.render)
    
    # 결과 저장
    result_dir = evaluator.save_results(results, prefix=args.result_prefix)
    
    LOGGER.info(f"평가 완료: 결과 저장 경로 {result_dir}")
    LOGGER.info(f"총 수익률: {results['total_return']:.2f}%")
    LOGGER.info(f"샤프 비율: {results['sharpe_ratio']:.2f}")
    LOGGER.info(f"최대 낙폭: {results['max_drawdown']:.2f}%")

if __name__ == "__main__":
    main() 
#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import argparse
import pandas as pd
import numpy as np
import json
import torch
import matplotlib.pyplot as plt
from datetime import datetime
import sys

# 상위 디렉토리를 path에 추가
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.models.sac_agent import SACAgent
from src.environment.trading_env import TradingEnvironment
from src.utils.logger import Logger
from src.config.config import Config
from src.backtesting.backtester import Backtester
from src.backtesting.visualizer import Visualizer


def parse_args():
    """
    명령행 인자 파싱
    """
    parser = argparse.ArgumentParser(description='SAC 모델 백테스트 실행')
    
    parser.add_argument('--model_path', type=str, required=True,
                        help='학습된 모델의 경로')
    parser.add_argument('--config_path', type=str, required=True,
                        help='설정 파일 경로')
    parser.add_argument('--data_path', type=str, required=True,
                        help='테스트 데이터 경로')
    parser.add_argument('--results_dir', type=str, default='results/backtest',
                        help='결과 저장 디렉토리')
    parser.add_argument('--initial_balance', type=float, default=10000.0,
                        help='초기 자본금')
    parser.add_argument('--commission_rate', type=float, default=0.0025,
                        help='거래 수수료율 (0.0025 = 0.25%)')
    parser.add_argument('--benchmark_data_path', type=str, default=None,
                        help='벤치마크 데이터 경로 (옵션)')
    parser.add_argument('--window_size', type=int, default=None,
                        help='관측 창 크기 (설정에서 가져오지 않을 경우)')
    
    return parser.parse_args()


def load_model(model_path, config, device):
    """
    학습된 모델 로드
    
    Args:
        model_path: 모델 경로
        config: 설정 객체
        device: 연산 장치
        
    Returns:
        로드된 SAC 에이전트
    """
    try:
        # SAC 에이전트 초기화
        agent = SACAgent(
            state_dim=config.state_dim,
            action_dim=config.action_dim,
            hidden_dim=config.hidden_dim,
            actor_learning_rate=config.actor_lr,
            critic_learning_rate=config.critic_lr,
            alpha_learning_rate=config.alpha_lr,
            gamma=config.gamma,
            tau=config.tau,
            batch_size=config.batch_size,
            device=device,
            initial_alpha=config.initial_alpha,
            target_entropy=config.target_entropy
        )
        
        # 저장된 모델 로드
        agent.load_model(model_path)
        print(f"모델을 성공적으로 로드했습니다: {model_path}")
        return agent
    except Exception as e:
        print(f"모델 로드 중 오류 발생: {e}")
        sys.exit(1)


def load_data(data_path):
    """
    테스트 데이터 로드
    
    Args:
        data_path: 데이터 파일 경로
        
    Returns:
        로드된 데이터 DataFrame
    """
    try:
        # 파일 확장자 확인
        if data_path.endswith('.csv'):
            data = pd.read_csv(data_path)
        elif data_path.endswith('.parquet'):
            data = pd.read_parquet(data_path)
        elif data_path.endswith('.h5'):
            data = pd.read_hdf(data_path)
        else:
            print(f"지원되지 않는 파일 형식: {data_path}")
            sys.exit(1)
            
        print(f"테스트 데이터 로드 완료: {len(data)} 행")
        return data
    except Exception as e:
        print(f"데이터 로드 중 오류 발생: {e}")
        sys.exit(1)


def load_benchmark_data(benchmark_path):
    """
    벤치마크 데이터 로드
    
    Args:
        benchmark_path: 벤치마크 데이터 파일 경로
        
    Returns:
        로드된 벤치마크 수익률 배열
    """
    try:
        if benchmark_path is None:
            return None
            
        # 파일 확장자 확인
        if benchmark_path.endswith('.csv'):
            data = pd.read_csv(benchmark_path)
        elif benchmark_path.endswith('.parquet'):
            data = pd.read_parquet(benchmark_path)
        elif benchmark_path.endswith('.h5'):
            data = pd.read_hdf(benchmark_path)
        else:
            print(f"지원되지 않는 벤치마크 파일 형식: {benchmark_path}")
            return None
            
        # 수익률 컬럼 확인 및 추출
        if 'return' in data.columns:
            returns = data['return'].values
        elif 'returns' in data.columns:
            returns = data['returns'].values
        elif 'daily_return' in data.columns:
            returns = data['daily_return'].values
        else:
            print("벤치마크 데이터에서 수익률 컬럼을 찾을 수 없습니다.")
            return None
            
        print(f"벤치마크 데이터 로드 완료: {len(returns)} 행")
        return returns
    except Exception as e:
        print(f"벤치마크 데이터 로드 중 오류 발생: {e}")
        return None


def setup_logger(results_dir):
    """
    로거 설정
    
    Args:
        results_dir: 결과 저장 디렉토리
        
    Returns:
        로거 객체
    """
    log_dir = os.path.join(results_dir, 'logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"backtest_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    return Logger(log_file)


def main():
    """
    메인 함수
    """
    # 명령행 인자 파싱
    args = parse_args()
    
    # 결과 디렉토리 설정
    results_dir = os.path.join(args.results_dir, datetime.now().strftime("%Y%m%d_%H%M%S"))
    os.makedirs(results_dir, exist_ok=True)
    
    # 로거 설정
    logger = setup_logger(results_dir)
    logger.info("백테스트 시작")
    logger.info(f"설정: {args}")
    
    # 설정 로드
    try:
        config = Config.load_config(args.config_path)
        logger.info("설정을 성공적으로 로드했습니다.")
        
        # 명령행에서 window_size가 지정된 경우 설정 업데이트
        if args.window_size is not None:
            config.window_size = args.window_size
            logger.info(f"window_size를 명령행 인자로 업데이트: {config.window_size}")
    except Exception as e:
        logger.error(f"설정 로드 중 오류 발생: {e}")
        sys.exit(1)
    
    # 장치 설정 (GPU 사용 가능 여부 확인)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"사용할 장치: {device}")
    
    # 모델 로드
    agent = load_model(args.model_path, config, device)
    
    # 테스트 데이터 로드
    test_data = load_data(args.data_path)
    
    # 벤치마크 데이터 로드 (있는 경우)
    benchmark_returns = load_benchmark_data(args.benchmark_data_path)
    
    # 백테스터 초기화
    backtester = Backtester(
        agent=agent,
        test_data=test_data,
        config=config,
        logger=logger,
        initial_balance=args.initial_balance,
        commission_rate=args.commission_rate
    )
    
    # 백테스트 실행
    logger.info("백테스트 실행 중...")
    results = backtester.run_backtest(verbose=True)
    
    # 결과 저장
    results_file = os.path.join(results_dir, "backtest_results.json")
    backtester.save_results(results_file)
    logger.info(f"백테스트 결과를 {results_file}에 저장했습니다.")
    
    # 시각화
    visualizer = Visualizer(results, save_dir=os.path.join(results_dir, "plots"))
    
    try:
        logger.info("백테스트 결과 시각화 중...")
        visualizer.visualize_all(benchmark_returns=benchmark_returns)
        logger.info("시각화 완료")
    except Exception as e:
        logger.error(f"시각화 중 오류 발생: {e}")
    
    # 최종 성능 지표 로깅
    logger.info("백테스트 성능 지표:")
    logger.info(f"초기 자본금: ${args.initial_balance:.2f}")
    logger.info(f"최종 포트폴리오 가치: ${results['portfolio_values'][-1]:.2f}")
    logger.info(f"누적 수익률: {results['metrics']['cumulative_return']:.2%}")
    logger.info(f"연간 수익률: {results['metrics']['annual_return']:.2%}")
    logger.info(f"샤프 비율: {results['metrics']['sharpe_ratio']:.2f}")
    logger.info(f"최대 낙폭: {results['metrics']['max_drawdown']:.2%}")
    logger.info(f"총 거래 횟수: {results['metrics']['total_trades']}")
    logger.info(f"승률: {results['metrics']['win_rate']:.2%}")
    
    logger.info("백테스트가 성공적으로 완료되었습니다.")
    
    return results


if __name__ == "__main__":
    main() 
"""
주식 데이터 전처리 및 특성 추출 모듈
"""
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Union, Optional, Any
from pathlib import Path
import talib
from sklearn.preprocessing import MinMaxScaler

from src.config.config import (
    WINDOW_SIZE,
    TRAIN_RATIO,
    VALID_RATIO,
    TEST_RATIO,
    DATA_DIR,
    LOGGER
)
from src.utils.utils import create_directory, save_to_csv, load_from_csv

class DataProcessor:
    """
    주식 데이터 전처리 및 특성 추출 클래스
    """
    
    def __init__(self, window_size: int = WINDOW_SIZE):
        """
        DataProcessor 클래스 초기화
        
        Args:
            window_size: 특성 추출을 위한 윈도우 크기
        """
        self.window_size = window_size
        self.scalers = {}  # 심볼별 스케일러 저장
        LOGGER.info(f"DataProcessor 초기화 완료: 윈도우 크기 {window_size}")
    
    def preprocess_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        주식 데이터 전처리 (결측치 처리, 이상치 제거 등)
        
        Args:
            data: 원본 주식 데이터 데이터프레임
            
        Returns:
            전처리된 데이터프레임
        """
        if data.empty:
            LOGGER.warning("빈 데이터프레임이 입력되었습니다.")
            return data
        
        # 결측치 처리
        data = data.copy()
        data.fillna(method='ffill', inplace=True)  # 앞의 값으로 채우기
        data.fillna(method='bfill', inplace=True)  # 뒤의 값으로 채우기
        
        # 중복 인덱스 제거
        data = data[~data.index.duplicated(keep='first')]
        
        # 0 또는 음수 값 처리 (거래량은 0일 수 있음)
        for col in ['open', 'high', 'low', 'close']:
            if col in data.columns:
                # 0 또는 음수 값을 가진 행 식별
                mask = data[col] <= 0
                if mask.any():
                    LOGGER.warning(f"{col} 열에서 {mask.sum()}개의 0 또는 음수 값이 발견되었습니다.")
                    # 해당 행을 제거하거나 대체할 수 있음
                    # 여기서는 이전 값으로 대체
                    data.loc[mask, col] = data[col].shift(1)[mask]
        
        LOGGER.info(f"데이터 전처리 완료: {len(data)} 행")
        return data
    
    def extract_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        기술적 지표를 계산하여 특성 추출
        
        Args:
            data: 전처리된 주식 데이터 데이터프레임
            
        Returns:
            특성이 추가된 데이터프레임
        """
        if data.empty:
            LOGGER.warning("빈 데이터프레임이 입력되었습니다.")
            return data
        
        df = data.copy()
        
        # 기본 가격 데이터
        open_prices = df['open'].values
        high_prices = df['high'].values
        low_prices = df['low'].values
        close_prices = df['close'].values
        volumes = df['volume'].values
        
        try:
            # 이동평균선
            df['ma5'] = talib.SMA(close_prices, timeperiod=5)
            df['ma10'] = talib.SMA(close_prices, timeperiod=10)
            df['ma20'] = talib.SMA(close_prices, timeperiod=20)
            df['ma60'] = talib.SMA(close_prices, timeperiod=60)
            df['ma120'] = talib.SMA(close_prices, timeperiod=120)
            
            # 볼린저 밴드
            df['upper_band'], df['middle_band'], df['lower_band'] = talib.BBANDS(
                close_prices, timeperiod=20, nbdevup=2, nbdevdn=2, matype=0
            )
            
            # MACD
            df['macd'], df['macd_signal'], df['macd_hist'] = talib.MACD(
                close_prices, fastperiod=12, slowperiod=26, signalperiod=9
            )
            
            # RSI
            df['rsi'] = talib.RSI(close_prices, timeperiod=14)
            
            # 스토캐스틱 오실레이터
            df['slowk'], df['slowd'] = talib.STOCH(
                high_prices, low_prices, close_prices,
                fastk_period=5, slowk_period=3, slowk_matype=0,
                slowd_period=3, slowd_matype=0
            )
            
            # ATR (Average True Range)
            df['atr'] = talib.ATR(high_prices, low_prices, close_prices, timeperiod=14)
            
            # OBV (On Balance Volume)
            df['obv'] = talib.OBV(close_prices, volumes)
            
            # 가격 변화율
            df['daily_return'] = df['close'].pct_change()
            df['log_return'] = np.log(df['close'] / df['close'].shift(1))
            
            # 이전 N일 종가 대비 현재 종가 비율
            for n in [1, 3, 5, 10]:
                df[f'close_ratio_{n}d'] = df['close'] / df['close'].shift(n)
            
            # 거래량 변화율
            df['volume_change'] = df['volume'].pct_change()
            
            # 고가-저가 범위
            df['high_low_range'] = (df['high'] - df['low']) / df['close']
            
            # 이동평균 교차 지표
            df['ma5_cross_ma20'] = (df['ma5'] > df['ma20']).astype(int)
            df['ma10_cross_ma60'] = (df['ma10'] > df['ma60']).astype(int)
            
            # 볼린저 밴드 관련 지표
            df['bb_width'] = (df['upper_band'] - df['lower_band']) / df['middle_band']
            df['bb_position'] = (df['close'] - df['lower_band']) / (df['upper_band'] - df['lower_band'])
            
        except Exception as e:
            LOGGER.error(f"특성 추출 중 오류 발생: {str(e)}")
            # 기본 특성만 사용
            df['daily_return'] = df['close'].pct_change()
        
        # NaN 값 처리
        df.fillna(method='ffill', inplace=True)
        df.fillna(method='bfill', inplace=True)
        df.fillna(0, inplace=True)
        
        LOGGER.info(f"특성 추출 완료: {len(df.columns)}개 특성")
        return df
    
    def normalize_features(self, data: pd.DataFrame, symbol: str, is_training: bool = True) -> pd.DataFrame:
        """
        특성 정규화
        
        Args:
            data: 특성이 추출된 데이터프레임
            symbol: 주식 심볼 (스케일러 구분용)
            is_training: 학습 데이터 여부
            
        Returns:
            정규화된 데이터프레임
        """
        if data.empty:
            return data
        
        df = data.copy()
        
        # 정규화에서 제외할 컬럼
        exclude_cols = ['date'] if 'date' in df.columns else []
        
        # 정규화할 컬럼
        cols_to_normalize = [col for col in df.columns if col not in exclude_cols]
        
        if is_training:
            # 학습 데이터인 경우 새 스케일러 생성
            scaler = MinMaxScaler()
            self.scalers[symbol] = scaler
            normalized_data = scaler.fit_transform(df[cols_to_normalize])
        else:
            # 테스트 데이터인 경우 기존 스케일러 사용
            if symbol not in self.scalers:
                LOGGER.warning(f"{symbol}에 대한 스케일러가 없습니다. 새로 생성합니다.")
                scaler = MinMaxScaler()
                self.scalers[symbol] = scaler
                normalized_data = scaler.fit_transform(df[cols_to_normalize])
            else:
                scaler = self.scalers[symbol]
                normalized_data = scaler.transform(df[cols_to_normalize])
        
        # 정규화된 데이터로 데이터프레임 생성
        normalized_df = pd.DataFrame(normalized_data, index=df.index, columns=cols_to_normalize)
        
        # 제외된 컬럼 다시 추가
        for col in exclude_cols:
            normalized_df[col] = df[col]
        
        LOGGER.info(f"{symbol} 데이터 정규화 완료")
        return normalized_df
    
    def create_window_samples(self, data: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        시계열 윈도우 샘플 생성
        
        Args:
            data: 정규화된 데이터프레임
            
        Returns:
            (X, y) 튜플: X는 윈도우 샘플, y는 다음 날 종가 변화율
        """
        if len(data) < self.window_size + 1:
            LOGGER.warning(f"데이터가 너무 적습니다. 최소 {self.window_size + 1}개 필요")
            return np.array([]), np.array([])
        
        # 다음 날 종가 변화율을 타겟으로 사용
        if 'daily_return' in data.columns:
            y = data['daily_return'].shift(-1).values[:-1]
        else:
            # daily_return이 없는 경우 계산
            y = (data['close'].shift(-1) / data['close'] - 1).values[:-1]
        
        # 윈도우 샘플 생성
        X = []
        for i in range(len(data) - self.window_size):
            X.append(data.iloc[i:i+self.window_size].values)
        
        X = np.array(X)
        y = y[-len(X):]  # X와 y의 길이 맞추기
        
        LOGGER.info(f"윈도우 샘플 생성 완료: X 형태 {X.shape}, y 형태 {y.shape}")
        return X, y
    
    def split_data(self, X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        데이터를 학습/검증/테스트 세트로 분할
        
        Args:
            X: 특성 데이터
            y: 타겟 데이터
            
        Returns:
            (X_train, X_valid, X_test, y_train, y_valid, y_test) 튜플
        """
        if len(X) == 0 or len(y) == 0:
            LOGGER.warning("빈 데이터가 입력되었습니다.")
            return np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])
        
        # 데이터 분할 인덱스 계산
        train_idx = int(len(X) * TRAIN_RATIO)
        valid_idx = int(len(X) * (TRAIN_RATIO + VALID_RATIO))
        
        # 시간 순서대로 분할 (미래 데이터 누수 방지)
        X_train, y_train = X[:train_idx], y[:train_idx]
        X_valid, y_valid = X[train_idx:valid_idx], y[train_idx:valid_idx]
        X_test, y_test = X[valid_idx:], y[valid_idx:]
        
        LOGGER.info(f"데이터 분할 완료: 학습 {len(X_train)}개, 검증 {len(X_valid)}개, 테스트 {len(X_test)}개")
        return X_train, X_valid, X_test, y_train, y_valid, y_test
    
    def process_symbol_data(self, data: pd.DataFrame, symbol: str) -> Dict[str, Any]:
        """
        단일 심볼 데이터에 대한 전체 전처리 과정 수행
        
        Args:
            data: 원본 주식 데이터 데이터프레임
            symbol: 주식 심볼
            
        Returns:
            전처리된 데이터와 분할된 데이터셋을 포함하는 딕셔너리
        """
        LOGGER.info(f"{symbol} 데이터 전처리 시작")
        
        # 1. 데이터 전처리
        processed_data = self.preprocess_data(data)
        if processed_data.empty:
            LOGGER.error(f"{symbol} 데이터 전처리 실패")
            return {}
        
        # 2. 특성 추출
        featured_data = self.extract_features(processed_data)
        
        # 3. 특성 정규화
        normalized_data = self.normalize_features(featured_data, symbol, is_training=True)
        
        # 4. 윈도우 샘플 생성
        X, y = self.create_window_samples(normalized_data)
        if len(X) == 0:
            LOGGER.error(f"{symbol} 윈도우 샘플 생성 실패")
            return {}
        
        # 5. 데이터 분할
        X_train, X_valid, X_test, y_train, y_valid, y_test = self.split_data(X, y)
        
        # 결과 반환
        result = {
            'processed_data': processed_data,
            'featured_data': featured_data,
            'normalized_data': normalized_data,
            'X_train': X_train,
            'X_valid': X_valid,
            'X_test': X_test,
            'y_train': y_train,
            'y_valid': y_valid,
            'y_test': y_test
        }
        
        LOGGER.info(f"{symbol} 데이터 전처리 완료")
        return result
    
    def process_all_symbols(self, data_dict: Dict[str, pd.DataFrame]) -> Dict[str, Dict[str, Any]]:
        """
        모든 심볼 데이터에 대한 전처리 수행
        
        Args:
            data_dict: 심볼을 키로 하고 데이터프레임을 값으로 하는 딕셔너리
            
        Returns:
            심볼을 키로 하고 전처리 결과를 값으로 하는 딕셔너리
        """
        results = {}
        
        for symbol, data in data_dict.items():
            try:
                result = self.process_symbol_data(data, symbol)
                if result:
                    results[symbol] = result
            except Exception as e:
                LOGGER.error(f"{symbol} 처리 중 오류 발생: {str(e)}")
        
        LOGGER.info(f"총 {len(results)}/{len(data_dict)} 종목 데이터 전처리 완료")
        return results
    
    def save_processed_data(self, results: Dict[str, Dict[str, Any]], base_dir: Union[str, Path] = None) -> None:
        """
        전처리된 데이터를 파일로 저장
        
        Args:
            results: 전처리 결과 딕셔너리
            base_dir: 저장할 기본 디렉토리 (None인 경우 기본값 사용)
        """
        if base_dir is None:
            base_dir = DATA_DIR / "processed"
        
        create_directory(base_dir)
        
        for symbol, result in results.items():
            # 데이터프레임만 저장
            for key in ['processed_data', 'featured_data', 'normalized_data']:
                if key in result and isinstance(result[key], pd.DataFrame):
                    save_dir = base_dir / symbol
                    create_directory(save_dir)
                    file_path = save_dir / f"{key}.csv"
                    save_to_csv(result[key], file_path)
        
        LOGGER.info(f"전처리된 데이터 저장 완료: {base_dir}")


if __name__ == "__main__":
    # 모듈 테스트 코드
    from src.data_collection.data_collector import DataCollector
    
    # 데이터 수집
    collector = DataCollector()
    data = collector.load_all_data()
    
    if not data:
        print("저장된 데이터가 없어 데이터를 수집합니다.")
        data = collector.collect_and_save()
    
    if data:
        # 데이터 전처리
        processor = DataProcessor()
        results = processor.process_all_symbols(data)
        processor.save_processed_data(results)
        
        # 첫 번째 종목의 결과 확인
        symbol = list(results.keys())[0]
        print(f"\n{symbol} 전처리 결과:")
        print(f"원본 데이터 크기: {data[symbol].shape}")
        print(f"전처리 데이터 크기: {results[symbol]['processed_data'].shape}")
        print(f"특성 추출 데이터 크기: {results[symbol]['featured_data'].shape}")
        print(f"학습 데이터 크기: {results[symbol]['X_train'].shape}")
        print(f"검증 데이터 크기: {results[symbol]['X_valid'].shape}")
        print(f"테스트 데이터 크기: {results[symbol]['X_test'].shape}") 